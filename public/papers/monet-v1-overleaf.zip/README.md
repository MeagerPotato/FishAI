# Monet v1.0 — the final paper, ready for Overleaf

## Open it

1. On Overleaf, choose **New Project → Upload Project** and select this zip.
2. The main file is `monet-v1.tex`. The compiler is **pdfLaTeX**, Overleaf's default.
3. Every package it uses ships with TeX Live: `amsmath`, `amssymb`, `booktabs`, `array`, `tabularx`, `longtable`,
   `xcolor`, `caption`, `microtype`, `enumitem`, `tikz`, `pgfplots` and `hyperref`.
4. The paper has no `.bib` file. The references are a `thebibliography` block at the end of `monet-v1.tex`.

The figures are drawn in the `.tex` itself with TikZ and pgfplots, and their data sit inline. Nothing else needs
uploading. The file compiles to 18 pages in two passes with no warnings.

## What is in here

| file | what it is |
|---|---|
| `monet-v1.tex` | The paper: the agent, the ladder from v0.1 to v1.0, the negative results, the findings about the game, the acceptance read, the comparison with Bass, SESTINA and Kraken, the limitations and the corrections. |
| `facts/acceptance-read.md` | The record of the acceptance read as it stands in `MONET.md` §3.8ba: every condition, every seed, the located control misses, the predictions and what was disclosed. |
| `README.md` | This file. |

## Editing the numbers

The acceptance read's numbers that recur are set once, as macros near the top of `monet-v1.tex`
(`\VSestMeanPct`, `\VCsixRead`, `\VPredScore` and the rest). Change them there, not in the text.

## Where the numbers come from

Every number in the paper is a number in `MONET.md`, the project's research record, and is cited by section.
`MONET.md` lives in the FishAI repository: https://github.com/MeagerPotato/FishAI/blob/main/MONET.md

- The acceptance read is §3.8ba.
- The definition of v1.0 is §3.9.
- The ladder is §3.8a to §3.8az, and the table at the top of the file indexes every rung.
- The decisions, with the owner's words, are the table in §8.3.

The paper adds no measurement of its own.

## One rule to keep

FishLab's repository has no licence file. The paper cites FishLab's measured findings as FishLab's own and
reproduces none of its code or prose. Keep it that way when editing.
