#### The read — 2026-09-18

**Read 10:43–11:01Z 2026-09-18. ALL SIX CONDITIONS HOLD AS THIS SECTION REGISTERED THEM, SO MONET v1.0
EXISTS, AND IT IS v0.54'S VECTOR, UNCHANGED.** One qualification belongs in the same sentence: **condition 5's
locked reader printed `CONDITION 5 NOT MET`.** It failed two rows, and the registration had already said how each
is decided, in words the reader cannot apply:

- **Twelve op counts sat outside the written expectation.** Each is located below to the engine's own records.
- **One cell of 72 has no calibration text file.** The per-process files carry its readout, which is how §6.2
  words the control and how §3.8at scored the same crash on twelve cells.

The reader's output is kept verbatim. **The owner may hold v1.0 to the reader's line instead**; the v1.0 entry would
then be withdrawn, and v0.54 stays shipped either way.

> | # | condition | read at v0.54's vector | verdict |
> |---|---|---|---|
> | 1 | ≥ 52.0% vs SESTINA over twelve seeds, paired floor ±2.00 | **58.38%** over 14,400 games; 56.38–60.38 with the floor. The stricter reading (a mean ≥ 54.0%) holds too | **MET** |
> | 2 | every seed ≥ 50.0%, every seed reported, SD published | lowest **56.58%**, highest 61.17%, SD **1.43**; 0 of 12 under 50 | **MET** |
> | 3 | v02 to v06 each beaten (≥ 52.00), and the order monotone | **84.43 / 81.20 / 56.91 / 57.92 / 58.24** against SESTINA's 58.38; the order holds through three ties inside the floor | **MET** |
> | 4 | declare accuracy ≥ 98.0% on every cell; zero fault counters | **99.494% to 99.857%** over 72 cells; the fourteen counters 0 in 2,587 per-process files; `FATAL` 0; `limit hits` 0% on 72/72 | **MET** |
> | 5 | every §6.2 control passes, the mirror cell not among them | the reader: **NOT MET** on two rows. The twelve band misses are located; the calibration readout is produced on 72 of 72 from the per-process files | **MET as registered**; the reader's line kept |
> | 6 | reproduced by a second, independently built arm | **P1:** 58.3819% against 58.3819%, every seed equal to four decimals and every other engine line equal on 12 of 12. **P2:** 14,400 of 14,400 games byte-identical. **P4:** the engine's own ask count identical on 12 of 12 | **MET** |

**Step 0: IDENTICAL** (09:31:38–09:34:14Z). The new arm played seed 4549308 at 800 deals and reproduced §3.8az D's
candidate cell. Every engine line but the arm's header and `elapsed` is identical: 57.8958% over 4,800 games,
declarations 99.7439% against SESTINA's 97.1617%. All 30 hello lines carried the label, all 36 cover files drained,
and the calibration readout covers 225,906 decisions. The lanes started after it.

**The pins.** Every recorded ask of the arm's 72 cells was replayed in-engine by `scripts/pin-bridge-asks.mjs
--version v0.54`, at the committed tree whose `lib/` is main `4551a9c`'s. **All 72 agree at every ask**; for
example, 56,894 of 56,894 on SESTINA at seed 1712760. **The mutation differs, as it must:** the same cell by
`--version v0.53` agrees at 36,697 of 56,894 asks and differs at 20,197 (35.50%). §3.8az's first cell differed at
35.9%. **The twin's 12 cells:** all 12 agree at every ask as well (10:57:21–11:01:19Z).

#### What ran, and the wall clock

> | stage | from | to | what |
> |---|---|---|---|
> | step 0 | 09:31:38Z | 09:34:14Z | one container; IDENTICAL |
> | lane 1 | 09:34:49Z | 10:17:02Z | SESTINA, v02, v03: 36 of 36 cells |
> | lane 2 | 09:34:53Z | 09:59:25Z | v04 and v05: 24 of 24 cells; v06: 3 of 12, then stopped on a fault (below) |
> | lane 2, relaunched | 10:00:20Z | 10:08:41Z | v06: the other 9 cells, the faulted one first |
> | condition 6 | 10:08:57Z | 10:56:56Z | the twin: 12 of 12 cells |
> | pins, the arm | 10:17:28Z | 10:43:37Z | 72 cells on two lanes, then the mutation (1,568 s) |
> | the readers, 1–5 | 10:43:50Z | 10:44Z | md5s re-verified first; the three unchanged |
> | pins, the twin | 10:57:21Z | 11:01:19Z | 12 cells on two lanes |
> | the reader, 6 | 11:01:27Z | | |

**About 1.5 hours of wall clock (09:31:38–11:01:27Z) from step 0 to the last reader, against the registered ~2.3
hours**, never more than two containers at a time. Docker Desktop was stopped at 10:58Z. No container was running,
ours or anyone's.

**The fault, and what was set aside.** At 09:57:37Z the cell `panel-v06-3881894` stopped at the handshake.

- **What happened.** The host's `hello` went unanswered for its 90 seconds. The bot's own `bot.log` is empty, so the
  process never reached its first line, and the record holds no game.
- **What the lane did.** It stops on any real fault by design (exit 3), and it did.
- **Why nothing was selected.** No move was played, so there was no result to keep or drop. The cell's four files are
  kept in `set-aside-handshake/`. The cell was replayed from its start on the same seed at 10:00:42Z, first in the
  relaunch, and the three v06 cells already complete were kept as they were.
- **The cause** is not located beyond the unanswered handshake: once in 84 cells, the 90 seconds the host allows ran
  out before the bot answered.

#### Conditions 1 and 2 — the SESTINA column

> | seed | 1712760 | 7550507 | 7705034 | 3881894 | 1665716 | 9181328 | 3434790 | 7342821 | 5822991 | 7099558 | 3491504 | 9112439 |
> |---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
> | vs SESTINA | 61.17 | 57.33 | 60.50 | 57.75 | **56.58** | 58.17 | 59.00 | 58.67 | 59.33 | 56.75 | 57.25 | 58.08 |

**58.38% over twelve seeds** (SD 1.43, SE 0.41). §3.8az D read 58.42% on twelve other seeds at four times the
deals.

- **Declarations, pooled.** Monet declared 4.64 sets a game at **99.757%**; SESTINA declared 4.29 at **96.916%**.
- **Sets.** Monet won 4.7975 a game to SESTINA's 4.2025, a differential of **+0.595 sets a game**. The exchange rate
  of §3.9 prices that at 58.06%.
- **Asks.** Monet's hit 52.77% of the time, SESTINA's 51.58%.

#### Condition 3 — the panel

> | opponent | mean | SD | lowest | highest | seeds under 50 | at v0.33 (§3.8ar, other seeds) |
> |---|---:|---:|---:|---:|---:|---:|
> | v02 | **84.43%** | 0.80 | 82.92 | 85.58 | 0 | 85.42% |
> | v03 | **81.20%** | 0.59 | 80.08 | 82.17 | 0 | 79.28% |
> | v04 | **56.91%** | 1.02 | 55.67 | 58.67 | 0 | 54.67% |
> | v05 | **57.92%** | 1.27 | 56.00 | 59.75 | 0 | 54.01% |
> | v06 | **58.24%** | 1.26 | 55.25 | 60.42 | 0 | 53.99% |
> | SESTINA | **58.38%** | 1.43 | 56.58 | 61.17 | 0 | 49.87% |

**"Beats" holds on five of five. "Monotone" holds only through ties, as §3.8ar read it.**

- **The order.** v04, v05, v06 and SESTINA sit within 1.47 points of one another. Monet's win rate rises slightly
  from v04 to SESTINA, the reverse of the order the condition names.
- **The ties.** Each adjacent pair is inside the ±2.00 floor, which the condition counts as a tie: v04 below v05 by
  1.01, v05 below v06 by 0.31, v06 below SESTINA by 0.15. Every pair, adjacent or not, is inside it too.
- **The risk Q3 named did not happen.** Q3's risk was SESTINA's column sitting more than the floor above v06's,
  which would have meant a gain against SESTINA alone. It sits 0.15 above.
- **Against v04 to v06 the win rate rose** from about 54% at v0.33 to 56.91–58.24%. The seeds differ, so this is not
  a paired comparison.

#### Condition 4

- **Declare accuracy**, from arm A's own engine line: **99.494% to 99.857%** over the 72 cells, none under 98.0.
  - By opponent: v02 99.602–99.841%, v03 99.494–99.689%, v04 99.578–99.854%, v05 99.675–99.854%, v06
    99.588–99.769%, SESTINA 99.646–99.857%.
- **The fourteen named counters are zero**, summed over the **2,587** per-process files that were written, and every
  one of the fourteen is present in every file.
- **Zero `FATAL` lines** across every cell's bot log.
- **`limit hits` 0%** on 72 of 72 cells.

#### Condition 5 — the locked reader's verdict, and what the registration makes of it

`v55-controls.cjs` (md5 `72a7e87b…`, re-verified at 10:43:50Z) printed the table below. It is kept verbatim but for
the reader's long cells, which are shortened here:

> | control of §6.2 | measured at v0.54's vector | verdict |
> |---|---|---|
> | **Op coverage** — every op exercised, `opPass` > 0 | `opAsk`, `opPoll`, `opPass`, `passfixDeclines`, `opForced` non-zero on 72/72; `opPass` > 0 on 72/72 | PASS |
> | " — the cross-check against the engine's own count | `opAsk` from the files = the engine's count of A's asks on **70/70** complete cells; short, never over, on 2/2 incomplete ones | PASS |
> | " — `newGames` | 3,600 on 70/70 complete cells | PASS |
> | " — the written expectation (§3.8ba) | 12 misses — PASS only if each is located to a cause that is neither play nor instrument | **FAIL** |
> | **Byte-exact null arm** | no mechanism is under test | n/a |
> | **Cross-instrument identity pin** | step 0: IDENTICAL | PASS |
> | **Paired deals** | 1,200 distinct (deal, rotation) keys in 72/72 records | PASS |
> | **The eleven named counters** | all 0 | PASS |
> | " — `limit hits` | 0% on 72/72 | PASS |
> | " — `auditViolations` | not scored: it has never performed a check (§3.8at's first amendment, still owed to §6.2) | not scored |
> | **Calibration harness** | readout produced on **71/72** cells (≥ 20,000 decisions, all ten deciles, the calib file); smallest 53,276 decisions | **FAIL** |
> | **Completion** | 72/72 | PASS |
> | **Home regression** | §3.8az C's 25,600 home games at this vector | PASS (on record) |
> | **No mirror cell** | 0 FishAI-vs-FishAI cells among 72 | PASS |
>
> `CONDITION 5 NOT MET`

Of the 2,592 processes, 2,587 wrote a readable cover file, 1 was torn and 4 never wrote one, so **70 of 72 cells are
complete**. The missing five are in two cells: `panel-v03-3491504` lost four (three never written, one torn) and
`panel-v02-5822991` lost one.

**The twelve band misses, each located.** The registration: *"The control passes when every op sits inside its band
on every complete cell, or when a miss is located to a cause that is neither a defect of play nor of the instrument
… An unlocated miss fails condition 5."* The locating probes (`v55-locate-stall.cjs`, `v55-locate-sestina.cjs`,
`v55-locate-post.cjs`, `v55-locate-mustfix.cjs`) were written after the reader printed its misses and are **not**
pre-registered. They read the engine's own records, which the adapter does not write.

1. **Ten `mustfixDeclines` misses, against v02 (8 of 11 complete cells) and v03 (2 of 11).** These two columns'
   bands came from v0.33's cells (§3.8ar), widened by ±15% *"because the vector has moved"*.
   - **What the counter counts.** MUSTFIX declines a poll only where `decide`'s window path is compelled (`decide.ts`
     `forced = stalled || must`) and the claim is not certain.
   - **Where the exposure comes from.** The `stalled` half is `isDeepStalled` over the public log: no hit for 12 log
     events and no claim for 24, or no claim for 60. It can be counted from the records without the adapter:

     > | opponent | vector | dead positions a game, before the clinch | MUSTFIX declines before the clinch, per complete cell | declines per dead position |
     > |---|---|---:|---:|---:|
     > | v02 | v0.33 | 0.134 | 517 | 3.22 |
     > | v02 | v0.54 | **0.346** | **1,261** | 3.03 |
     > | v03 | v0.33 | 0.044 | 231 | 4.51 |
     > | v03 | v0.54 | **0.118** | **489** | 3.41 |
     > | v04 | v0.33 | 5.154 | 16,455 | 3.01 |
     > | v04 | v0.54 | 5.366 | 19,365 | 3.01 |
     > | v05 | v0.33 | 0.046 | 228 | 4.61 |
     > | v05 | v0.54 | 0.044 | 265 | 5.00 |
     > | v06 | v0.33 | 0.039 | 263 | 6.13 |
     > | v06 | v0.54 | 0.042 | 276 | 5.50 |
     > | SESTINA | v0.33 | 0.036 | 212 | 4.68 |
     > | SESTINA | v0.54 | 0.062 | 316 | 4.23 |

   - **The finding.** v0.54's games against v02 and v03 reach the dead position about **2.6 times** as often as
     v0.33's did. The declines per dead position **did not rise**. Three is one decline for each of Monet's seats
     polled, which is what v04 shows at both vectors.
   - **The rise is before the clinch.** Pre 517 → 1,261 and 231 → 489, while post-clinch is flat (142 → 129,
     165 → 138). The exposure to the other compelled position, the FishLab team holding no cards, did not move
     (0.451 → 0.432 and 0.554 → 0.553 events a game).
   - **So the vector moved the exposure, not the counter.** The play is v0.54's at every ask (the pins). The
     instrument counts every ask exactly (the cross-check, 70 of 70). Against the two opponents it beats most easily,
     its games simply stall a little more often. That is a change of play, not a defect of it. The win rates against
     those two are 84.43% and 81.20%, against v0.33's 85.42% and 79.28% on other seeds.
2. **SESTINA 7550507 `opPoll` 372,561 against a top of 372,366 (+0.05%).** `opPoll` is three polls per recorded
   event, one for each of Monet's seats, on every one of the twelve cells (2.9996 to 2.9999). This seed played the
   most events of the twelve (124,198), so it has the most polls. The miss is the deal's length.
3. **SESTINA 1665716 `opForced` 1,429 against a top of 1,393 (+2.6%).** This seed had the most games with a forced
   claim of the twelve (108, from 53 to 86 on the others). Its forced polls per such game, 13.23, sit inside the
   others' 10.93–16.06. §6.2 already calls this op seed-variable.

**Why the SESTINA band was narrow**, stated so the next expectation is written better. It was built from v0.54's own
4,800-game cells, each scaled to 1,200 games. A scaled total varies half as much as a real 1,200-game cell, so a
band from its range is too tight for these cells. The v02 and v03 bands had the opposite problem: they came from
another vector.

**The calibration row.** The per-process file `cover-10603-2568972598546.json` of `panel-v03-3491504` is 0 bytes.
`sum-calib.mjs` parses every file without a guard, so it threw on that file, and its `tee` wrote an empty
`calib-panel-v03-3491504.txt`.

- **What §6.2 words.** The control is *"believed vs realised per decile on ≥ 20,000 decisions, on every cell"*.
- **What the files carry.** The reader's own checks of that are on the per-process counters: **≥ 20,000 decisions
  and all ten deciles on 72 of 72** (the smallest is this cell's 53,276).
- **What the reader added.** The one thing it adds is the text file. It added it on the registration's note that
  §3.8ar's twelve missing files were *"not on disk"*. They are missing because the same harness crashed on them
  (corrected in the note above), and §3.8at scored those twelve as produced.
- **The readout, written out.** The harness was re-run over the cell's 32 readable files into a separate file,
  `calib-panel-v03-3491504.rerun.txt`: n = 53,276, all ten deciles populated, aggregate bias −0.0162. Its
  neighbours read −0.0137 to −0.0205.

**Condition 5's verdict: MET as registered.** The registration decides both failing rows, and on its rules both
pass:

- **The band row:** every miss is located to the engine's own records, to causes that are neither play defects nor
  instrument defects.
- **The calibration row:** by §6.2's wording and §3.8at's scoring, the readout is produced on 72 of 72.

**The reader's line, `CONDITION 5 NOT MET`, stays printed above.** If the owner reads condition 5 by the reader's
line, v1.0 does not exist on this read.

#### Condition 6 — the independently built arm

`v55-c6.cjs` (md5 `55cb31b7…`, re-verified at 11:01:27Z) printed **`CONDITION 6 MET (P1 holds, P2 holds, P4
holds)`**.

**The twin.** It is `monet-v54-indep`: `arm.mjs` `2741a563`, with `bot.mjs` `4f524e71` and `translate.mjs`
`fc3acf98`. It played SESTINA on the same twelve seeds, on the same tree export.

**P1 HOLDS, on every seed, to four decimals.**

> | seed | the arm (this project's adapter) | the twin (the independent adapter) |
> |---|---:|---:|
> | 1712760 | 61.1667% | 61.1667% |
> | 7550507 | 57.3333% | 57.3333% |
> | 7705034 | 60.5000% | 60.5000% |
> | 3881894 | 57.7500% | 57.7500% |
> | 1665716 | 56.5833% | 56.5833% |
> | 9181328 | 58.1667% | 58.1667% |
> | 3434790 | 59.0000% | 59.0000% |
> | 7342821 | 58.6667% | 58.6667% |
> | 5822991 | 59.3333% | 59.3333% |
> | 7099558 | 56.7500% | 56.7500% |
> | 3491504 | 57.2500% | 57.2500% |
> | 9112439 | 58.0833% | 58.0833% |
> | **pooled** | **58.3819%** | **58.3819%** |

Every other engine line is equal on 12 of 12 cells as well.

**P2 HOLDS: 14,400 of 14,400 games are byte-identical.**

- **How they were matched.** On `(deal, rotation)`, with the same 1,200 keys on both sides on every seed.
- **The headers** differ on one field only, `specA`, the arm's package id, which must differ.
- **Against §3.8at.** §3.8at found 4 games of 14,400 differing, all at one position: which teammate of a team
  already certain of a set emits the declare. No game differs here, and nothing is inferred from that.

**P4 HOLDS.** The engine's own count of A's asks is identical on 12 of 12 cells (56,894 on both at seed 1712760).

**The twin's own counters**, read as information because its stderr is lossy (415 of 432 `COVER` lines):
`viewFaults`, `fallbacks`, `errors`, `fatals` and `forcedNone` are all 0, and there are 0 `FATAL` lines.

**The twin's pins.** All 12 cells agree at every ask by `--version v0.54` (10:57:21–11:01:19Z).

#### The predictions, scored

> | | registered | outcome |
> |---|---:|---|
> | Q1 — condition 1 holds | 97% | **HIT**: 58.38%, more than twelve SE above 52.0 |
> | Q2 — condition 2 holds | 95% | **HIT**: the lowest seed 56.58%, more than four SD above 50.0 |
> | Q3 — condition 3 holds | 65% | **HIT**. The risk named was the order breaking at v06 ≥ SESTINA, and SESTINA sits 0.15 above v06 |
> | Q4 — condition 4 holds | 93% | **HIT**: the worst cell 99.494% |
> | Q5 — condition 5 holds | 85% | **HIT as registered**. The bands missed twelve times, each for a located reason, which is how Q5 said it could go. The reader's own line is NOT MET |
> | Q6 — condition 6 holds | 85% | **HIT: P1, P2 and P4 all hold; 14,400 of 14,400 games byte-identical, above the 99.9% bar** |
> | joint | ~45% | **all six held** |

#### Disclosed

- **What was seen before the readers ran.** The engine lines of four of the read's 84 cells had been looked at before
  10:43:50Z:
  - `panel-v03-7099558` (81.25%) and `panel-v03-3491504` (80.67%), in the lane log around the calibration crash,
    during the lanes;
  - `c6-sestina-9181328` (58.17%) and `panel-sestina-1712760` (61.17%), at 10:38–10:41Z, while this record was being
    prepared.

  The readers' files were last written at 09:33:54–09:35:43Z, before the first cell of the read finished (09:35:47Z).
  Their md5s were written at 09:36:32Z and committed at 09:58:52Z (`1256f4b`). None of the four could move the
  scoring. The lane logs carry every cell's engine lines, as §3.8ar's and §3.8at's did; the runners' consoles print
  completion only.
- **Two sentences of the readers note are wrong or incomplete**, and they are corrected in place above.
- **The locating probes are post hoc.** They were written after the misses were printed, and they are named so.

**What it means.** §3.9 defines Monet v1.0 as the vector that meets its six conditions on one pre-registered read.
v0.54's vector met them here, as §3.8ba registered them. So, on the owner's direction of 2026-09-18, which this
section registered before any cell:

- the registry gains `v1.0`, equal to v0.54's vector key for key;
- /play seats it;
- the papers go on the site;
- the final paper is packaged for Overleaf.

**Nothing new is built into the agent.** v1.0 plays every game exactly as v0.54 does.
